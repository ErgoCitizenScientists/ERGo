# -*- coding: utf-8 -*-
"""
Cribbed from Joe Donovan's EEG class by DJP
"""

from datetime import datetime
from math import floor
import numpy as np
import os
import pandas as pd
from scipy.io import wavfile
from scipy.signal import butter, filtfilt
import matplotlib.pyplot as plt

import neo
import elephant
import quantities as pq

from trial import Trial 


class ERG:
    """
    A class for loading erg data saved as a wavefile with some metadata on the side
    Resamples data to a resamplerate
    """
    # https://docs.python.org/2/tutorial/modules.html
    def __init__(self, wav_file, text_file=None, resamplerate=None, subtract_baseline=True):
        '''
        Parameters
        ----------
        wav_file: str
            Path to wav data file.
            
        text_file: str
            Path to text file 
        
        resamplerate: int
            Target sample rate
            
        subtract_baseline: bool
            subtracts baseline from recording

        Returns
        -------
        ERG object.

        '''

        # Read in wave data
        samplerate, data = wavfile.read(wav_file)
        wavedata = data.copy() # Data is read-only
        
        if resamplerate == None:
            resamplerate = samplerate
        
        if subtract_baseline:
            wavedata -= np.median(wavedata).astype(wavedata.dtype)

        # resample to a fixed sample rate
        # have wavedata at samplerate, and want it at resamplerate
        sample_times = np.arange(len(wavedata)) / samplerate # in s
        
        new_sample_times = np.linspace(
            1, floor(sample_times[-1]), floor(sample_times[-1] * resamplerate) + 1)
        
        wavedata_resamp = np.zeros((len(new_sample_times),3))
        
        for channel in range(3):
            wavedata_resamp[:,channel] = np.interp(
                new_sample_times, sample_times, wavedata[:,channel])

        self.sample_times = new_sample_times
        self.sr = resamplerate
        wavedata = wavedata_resamp

        # filters raw data
        b,a=butter(1,[1 / (0.5 * self.sr),20/(0.5* self.sr)],btype='band')
        # First two are analogs
        wavedata[:,0] = filtfilt(b,a,wavedata[:,0])
        wavedata[:,1] = filtfilt(b,a,wavedata[:,1])
        # Third is TTL, unfiltered
        
        
        #%% Stimulus markers
        # Extract date
        yearstr = os.path.splitext(os.path.split(wav_file)[1])[0]
        self.datetime = datetime.strptime(yearstr[len('BYB_Recording_'):len('BYB_Recording_') + 19], '%Y-%m-%d_%H.%M.%S')  # Reference -  http://strftime.org/
        
        if text_file==None:
            text_file = wav_file[:-4] + '-events.txt'
            
        with open (text_file, "r") as tf:
            rawtextdata=tf.readlines()
            
        # remove first two lines and then remove commas, then the last character (a newline)
        textdata = [e.replace(',','')[:-1] for e in rawtextdata[2:]]
        # make a list of lists to put into dataframe
        textdata = [e.split('\t') for e in textdata]
        
        # cast as float
        self.stim_df = pd.DataFrame(
            textdata, columns=['markers','timestamps'],dtype='float')
        
        self.signal = neo.AnalogSignal(
            wavedata,units=pq.mV,
            sampling_rate=resamplerate * pq.Hz,
            file_origin=wav_file, description='channel 1, channel 2, and TTL')     
        
        self.trials, channel1,channel2,TTL =[],[],[],[]
        for stim_ind in range(len(self.stim_df)):
            window = ()
            get_ts = lambda s_df, st_ind, offset : (s_df.timestamps[st_ind] + offset) * pq.s
            if stim_ind == len(self.stim_df) - 1:
                # if it's the last one, just take the next two seconds as manual offset
                window = (get_ts(self.stim_df, stim_ind, 0), get_ts(self.stim_df, stim_ind, 2))
            else: # if not the last one, take current to the next.
                window = (get_ts(self.stim_df, stim_ind, 0), get_ts(self.stim_df, stim_ind+1,0))
                
            slice = self.signal.time_slice(*window)

            channel1.append(slice[:,0])
            channel2.append(slice[:,1])
            # average periods, convert to frequencies
            onsets = np.where(np.diff(slice[:,2]) > 1500)[0]
            freq = 1/np.mean(np.diff(onsets)) * pq.Hz
            
            self.trials.append(Trial(window, slice))
        
        
    
    def vizCFF(self):
        '''
        Show grid of raw data from CFF visualization, maybe also a Bode plot. May want to break up into different parts
            1 2 4 8 16 32 64 128 254 512
        IR
        R
        G
        B
        UV
        
        '''
        color_to_y = {'IR':0,'R':1,'G':2,'B':3,'UV':4}
        freq_to_x = {2**ind:ind for ind in range(10)}
        Trials = self.Trials
        
        fig,axs = plt.subplots(nrows = len(color_to_y), ncols = len(freq_to_x))
        
        for trial_ind in range(len(Trials)):
            current_Trial = Trials[trial_ind]
            freq_key, color_key = current_Trial.freq, current_Trial.color
            freq_ind, color_ind = freq_to_x[freq_key], color_to_y[color_key]
            
            # Get appropriate subplot
            ax = axs[color_ind, freq_ind]
                        
            ax.plot(current_Trial.trace)
            ax.axis('off')
            ax.set_title('freq: {}, color: {}'.format(freq_key, color_key) )
        
        # get max ylim for subplots
        ymin,ymax = 0,0
        for row in range(len(color_to_y)):
            for col in range(len(freq_to_x)):
                yl = axs[row,col].get_ylim()
                ymin, ymax = min(ymin, yl[0]), max(ymax, yl[1])
        
        # set ylim for all subplots
        for row in range(len(color_to_y)):
            for col in range(len(freq_to_x)):
                axs[row,col].set_ylim((ymin,ymax))
    
if __name__ == '__main__':
    
    # ergram = ERG(r'C:\Users\danpo\Documents\BYB\BYB_Recording_2020-03-22_18.00.44.wav')
    # ergram.vizCFF()
    
    # ergram = ERG(r'C:\Users\danpo\Documents\BYB\BYB_Recording_2020-03-22_17.52.20.wav')
    # ergram.vizCFF()
    
    # ergram = ERG(r'C:\Users\danpo\Documents\BYB\BYB_Recording_2020-03-22_16.50.13.wav')
    # ergram.vizCFF()
    
    # ergram = ERG(r'C:\Users\danpo\Documents\BYB\BYB_Recording_2020-08-14_11.31.22.wav')
    # ergram.vizCFF()
    ergram = ERG(r'C:\Users\danpo\Documents\BYB\BYB_Recording_2020-08-14_16.10.46.wav')
    def show_alignment(sr):
        plt.plot(ergram.signal[:,2])
        for i in range(len(ergram.stim_df)):
            plt.plot(ergram.stim_df.timestamps[i] * sr, 4e3, '*r')
    show_alignment(3e3)
        