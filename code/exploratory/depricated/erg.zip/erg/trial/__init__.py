# -*- coding: utf-8 -*-
"""
Created on Fri Apr 24 13:53:52 2020

@author: danpo
"""
import numpy as np
import quantities as pq
import neo


class Trial:
 
    def __init__(self, timestamps, trace, color=None, frequency=None):
       self.trace = trace
       self.timestamps = timestamps
       self.color, self.frequency = None, None